package no.hvl.dat110.aciotdevice.client;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.io.IOException;

import com.google.gson.Gson;

public class RestClient {

	public RestClient() {}

	private static String logpath = "/accessdevice/log";
	private static String codepath = "/accessdevice/code";


public void doPostAccessEntry(String message) {
		
		OkHttpClient client = new OkHttpClient();
		Request request = new Request.Builder()
				.url("http://localhost:8080" + logpath)
				.post(RequestBody.create(MediaType.parse("Text/plain"), message))
				.build();
		try {
			System.out.println(client.newCall(request).execute().body().string());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
		
	public AccessCode doGetAccessCode() {

		AccessCode code = null;
		OkHttpClient client = new OkHttpClient();
		Request request = new Request.Builder()
				.url("http://localhost:8080" + codepath)
				.get()
				.build();
		
		try {
			code = new Gson().fromJson(client.newCall(request).execute().body().string(), AccessCode.class);
		} catch(IOException e) {
			e.printStackTrace();
		}	
		
		return code;
	}
}