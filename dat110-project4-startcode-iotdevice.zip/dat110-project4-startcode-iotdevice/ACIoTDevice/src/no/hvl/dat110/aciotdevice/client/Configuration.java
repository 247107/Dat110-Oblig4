package no.hvl.dat110.aciotdevice.client;

public class Configuration {

	// specification of the host and port where the cloud service is running
	public static int port = 8080;
    public static String host = "localhost";

}
