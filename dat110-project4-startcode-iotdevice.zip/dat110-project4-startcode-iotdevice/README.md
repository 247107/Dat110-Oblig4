# dat110-project4-startcode-iotdevice
Start code for the IoT device
