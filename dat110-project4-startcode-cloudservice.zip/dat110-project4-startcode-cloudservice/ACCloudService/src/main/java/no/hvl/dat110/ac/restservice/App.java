package no.hvl.dat110.ac.restservice;

import static spark.Spark.after;
import static spark.Spark.get;
import static spark.Spark.port;
import static spark.Spark.put;
import static spark.Spark.post;
import static spark.Spark.delete;

import com.google.gson.Gson;

/**
 * Hello world!
 *
 */
public class App {
	
	static AccessLog accesslog = null;
	static AccessCode accesscode = null;
	
	public static void main(String[] args) {

		if (args.length > 0) {
			port(Integer.parseInt(args[0]));
		} else {
			port(8080);
		}

		// objects for data stored in the service
		
		accesslog = new AccessLog();
		accesscode  = new AccessCode();
		
		after((req, res) -> {
  		  res.type("application/json");
  		});
		
		get("/accessdevice/hello", (req, res) -> {
		 	return new Gson().toJson("IoT Access Control Device");
		});
		
		post("/accessdevice/log", (req, res) -> {
		 	return new Gson().toJson(accesslog.get(accesslog.add(req.body())));
		});
		
		get("/accessdevice/log", (req, res) -> {
		 	return accesslog.toJson();
		});
		
		get("/accessdevice/log/:id", (req, res) -> {
		 	return new Gson().toJson(accesslog.get(Integer.parseInt(req.params("id"))));
		});
		
		put("/accessdevice/code", (req, res) -> {
			Gson gson = new Gson();
			accesscode.setAccesscode(gson.fromJson(req.body(), AccessCode.class).getAccesscode());
		 	return gson.toJson(accesscode.getAccesscode());
		});
		
		delete("/accessdevice/log", (req, res) -> {
			accesslog.clear();
		 	return accesslog.toJson();
		});		
    }
}
